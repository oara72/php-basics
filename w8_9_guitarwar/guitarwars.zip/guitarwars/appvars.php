<DOCTYPE html>
<html>
<head>
	<title>appvars.php</title>
	
<body>
	
	
<?php
	
	//Defining constants to be used by the application
	define('GW_UPLOADPATH','/home/w0668944/public_html/guitarwars/images/');
	define('GW_DISPLAYPATH','images/');
	define('GW_MAXFILESIZE',32768);
	

	?>

	
	

</body>
</html>