<!DOCTYPE>
<!--
Student Name: Salomon Aparicio F.
Student Number: w0668944
Last Date Modified: Feb. 10th, 2015
_________________________
Program name: connectvars.php
Purpose: connect with MySQL
-->
<html>
<head>
	<title>PHP Database by Salomon Aparicio</title>
</head>
<Body>
	<?php
	// Define the database connection constants here!
	define('DB_HOST', 'localhost');
	define('DB_USER', 'w0668944');
	define('DB_PASSWORD', 'bz0ibz0i');
	define('DB_NAME', 'w0668944db');
	?>
	
</body>
</html>